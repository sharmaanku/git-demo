/**
 * Authentication components for the payment application exercise.
 */
package com.technova.payment.auth;
