package com.technova.payment;

public class Main {
    public static void main(String[] args) {
        System.out.println("Payment application starter project");
        System.out.println("Login functionality is intentionally not implemented.");
    }
}
