import pandas as pd
from calculations.variance_calculator import build_variance_analysis

def test_expense_variance_calculation():
    budget = pd.DataFrame([{
        "Period":"Jan", "Entity":"India", "Department":"IT",
        "Account":"Infrastructure", "Account Type":"Expense", "Amount":500
    }])
    actuals = pd.DataFrame([{
        "Period":"Jan", "Entity":"India", "Department":"IT",
        "Account":"Infrastructure", "Account Type":"Expense", "Amount":650
    }])
    result = build_variance_analysis(budget, actuals, "Jan").iloc[0]
    assert result["Variance"] == 150
    assert result["Variance %"] == 30
    assert result["Variance Status"] == "Unfavourable"
