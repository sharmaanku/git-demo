import streamlit as st
import pandas as pd
from calculations.variance_calculator import build_variance_analysis
from workflows.epm_orchestrator import EPMOrchestrator
from reports.report_generator import to_excel_bytes
from config.settings import APP_TITLE

st.set_page_config(page_title=APP_TITLE, layout="wide")
st.title("SmartEPM | Agentic Financial Planning & Variance Analysis")
st.caption("EPM-inspired demonstration application using Python, Streamlit and Claude.")

@st.cache_data
def load_data():
    budget = pd.read_csv("data/budget.csv")
    actuals = pd.read_csv("data/actuals.csv")
    forecast = pd.read_csv("data/forecast.csv")
    return budget, actuals, forecast

budget, actuals, forecast = load_data()
periods = sorted(actuals["Period"].unique())
period = st.sidebar.selectbox("Financial period", periods, index=0)
threshold = st.sidebar.slider("Unfavourable variance threshold (%)", 1, 100, 15)

st.sidebar.markdown("---")
st.sidebar.write("**Data source:** bundled demonstration CSV files")
st.sidebar.write("**AI mode:** Claude API when ANTHROPIC_API_KEY is configured; deterministic fallback otherwise.")

variance = build_variance_analysis(budget, actuals, period=period)
variance["Threshold Status"] = variance.apply(
    lambda r: "Critical" if r["Variance %"] > threshold and r["Account Type"] == "Expense"
    else ("Review" if r["Variance %"] > threshold else "Within threshold"), axis=1
)

total_budget = variance["Budget"].sum()
total_actual = variance["Actual"].sum()
total_variance = total_actual - total_budget
c1, c2, c3, c4 = st.columns(4)
c1.metric("Budget", f"₹{total_budget:,.0f}")
c2.metric("Actual", f"₹{total_actual:,.0f}")
c3.metric("Net variance", f"₹{total_variance:,.0f}", delta=f"{(total_variance / total_budget * 100) if total_budget else 0:.1f}%")
c4.metric("Departments to review", int((variance["Threshold Status"] == "Critical").sum()))

st.subheader(f"Budget vs Actual — {period}")
st.dataframe(variance, use_container_width=True, hide_index=True)
st.bar_chart(variance.set_index("Department")[["Budget", "Actual"]])

st.subheader("Agentic EPM workflow")
question = st.text_area(
    "Ask the EPM agents",
    value=f"Analyse {period} performance and identify expense departments exceeding the threshold of {threshold}%. Explain the exceptions and recommend next actions."
)
if st.button("Run EPM agent workflow", type="primary"):
    orchestrator = EPMOrchestrator()
    with st.spinner("Running data, analysis, anomaly, commentary and reporting agents..."):
        result = orchestrator.run(
            budget=budget, actuals=actuals, period=period,
            threshold_pct=threshold, user_request=question
        )
    st.success("Workflow completed")
    st.markdown("### Data validation")
    st.json(result["data_validation"])
    st.markdown("### Variance and anomaly findings")
    st.dataframe(result["exceptions"], use_container_width=True, hide_index=True)
    st.markdown("### AI financial commentary")
    st.write(result["commentary"])
    st.markdown("### Recommended actions")
    for item in result["recommendations"]:
        st.write(f"- {item}")
    st.download_button(
        "Download EPM variance report (Excel)",
        data=to_excel_bytes(result["exceptions"]),
        file_name=f"SmartEPM_{period}_variance_report.xlsx",
        mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

st.caption("Training/demo use only. Figures are synthetic and are not financial advice.")
