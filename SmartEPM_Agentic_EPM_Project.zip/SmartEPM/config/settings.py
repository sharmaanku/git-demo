APP_TITLE = "SmartEPM | Agentic EPM Demo"
