from io import BytesIO
import pandas as pd

def to_excel_bytes(dataframe):
    output = BytesIO()
    with pd.ExcelWriter(output, engine="openpyxl") as writer:
        dataframe.to_excel(writer, index=False, sheet_name="Variance Analysis")
    return output.getvalue()
