class AnomalyDetectionAgent:
    def detect(self, variance_df, threshold_pct=15):
        result = variance_df.copy()
        expense_overrun = (
            (result["Account Type"] == "Expense") &
            (result["Variance %"] > threshold_pct)
        )
        revenue_shortfall = (
            (result["Account Type"] == "Revenue") &
            (result["Variance %"] < -threshold_pct)
        )
        result["Anomaly"] = expense_overrun | revenue_shortfall
        result["Severity"] = result.apply(
            lambda r: "Critical" if r["Anomaly"] and abs(r["Variance %"]) >= 30
            else ("Warning" if r["Anomaly"] else "Normal"), axis=1
        )
        return result
