class EPMReportingAgent:
    def recommendations(self, exceptions):
        flagged = exceptions[exceptions["Anomaly"]]
        if flagged.empty:
            return ["Continue monthly monitoring and retain the approved budget baseline."]
        actions = []
        for department in flagged["Department"].drop_duplicates():
            actions.append(
                f"Ask the {department} budget owner to explain flagged accounts and attach supporting invoices or approvals."
            )
        actions.append("Record approved reforecasts separately; do not overwrite the original budget.")
        actions.append("Review threshold exceptions with the finance controller before taking corrective action.")
        return actions
