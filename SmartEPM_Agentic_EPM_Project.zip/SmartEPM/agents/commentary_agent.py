import os
import json

class FinancialCommentaryAgent:
    """Uses Claude when configured; otherwise creates transparent rule-based commentary."""
    def __init__(self):
        self.api_key = os.getenv("ANTHROPIC_API_KEY")

    def generate(self, exceptions, period, user_request=""):
        records = exceptions.to_dict(orient="records")
        if self.api_key:
            try:
                import anthropic
                client = anthropic.Anthropic(api_key=self.api_key)
                prompt = f"""
You are a finance business partner analysing synthetic EPM data for {period}.
User request: {user_request}
Validated calculation results (JSON): {json.dumps(records, default=str)}
Explain the material variances without inventing causes. Clearly distinguish observed facts
from hypotheses requiring investigation. Give concise, actionable recommendations.
Do not recalculate the numbers; use the supplied calculations.
"""
                response = client.messages.create(
                    model=os.getenv("CLAUDE_MODEL", "claude-3-5-sonnet-latest"),
                    max_tokens=900,
                    messages=[{"role": "user", "content": prompt}]
                )
                return "\n".join(block.text for block in response.content if hasattr(block, "text"))
            except Exception as exc:
                return self._fallback(exceptions, period) + f"\n\n[Claude API fallback: {type(exc).__name__}: {exc}]"
        return self._fallback(exceptions, period)

    def _fallback(self, exceptions, period):
        flagged = exceptions[exceptions["Anomaly"]]
        if flagged.empty:
            return f"No exceptions crossed the configured threshold for {period}. Continue routine monitoring."
        lines = [f"Financial review for {period}: {len(flagged)} line item(s) crossed the configured threshold."]
        for _, row in flagged.iterrows():
            lines.append(
                f"- {row['Department']} / {row['Account']}: actual ₹{row['Actual']:,.0f} "
                f"versus budget ₹{row['Budget']:,.0f}; variance ₹{row['Variance']:,.0f} "
                f"({row['Variance %']:.1f}%), {row['Severity'].lower()}."
            )
        lines.append("The dataset shows the size and location of the variances, but does not contain causal evidence.")
        lines.append("Recommended investigation: review invoices, purchase orders, headcount changes, usage records and approved budget revisions.")
        return "\n".join(lines)
