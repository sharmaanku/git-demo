class EPMDataAgent:
    """Validates the basic shape and completeness of EPM-style data."""
    REQUIRED = {"Period", "Entity", "Department", "Account", "Account Type", "Amount"}

    def validate(self, budget, actuals):
        issues = []
        for label, frame in [("budget", budget), ("actuals", actuals)]:
            missing_cols = self.REQUIRED - set(frame.columns)
            if missing_cols:
                issues.append(f"{label}: missing columns {sorted(missing_cols)}")
                continue
            if frame[list(self.REQUIRED)].isnull().any().any():
                issues.append(f"{label}: one or more required fields contain null values")
            if (frame["Amount"] < 0).any():
                issues.append(f"{label}: negative Amount values found; review these records")
        return {
            "status": "PASS" if not issues else "REVIEW",
            "budget_rows": len(budget),
            "actual_rows": len(actuals),
            "issues": issues
        }
