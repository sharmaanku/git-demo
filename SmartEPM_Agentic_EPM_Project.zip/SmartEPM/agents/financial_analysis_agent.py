from calculations.variance_calculator import build_variance_analysis

class FinancialAnalysisAgent:
    def analyse(self, budget, actuals, period):
        return build_variance_analysis(budget, actuals, period)
