from agents.data_agent import EPMDataAgent
from agents.financial_analysis_agent import FinancialAnalysisAgent
from agents.anomaly_agent import AnomalyDetectionAgent
from agents.commentary_agent import FinancialCommentaryAgent
from agents.reporting_agent import EPMReportingAgent

class EPMOrchestrator:
    """Coordinates specialised agents in a simple, inspectable sequence."""
    def __init__(self):
        self.data_agent = EPMDataAgent()
        self.analysis_agent = FinancialAnalysisAgent()
        self.anomaly_agent = AnomalyDetectionAgent()
        self.commentary_agent = FinancialCommentaryAgent()
        self.reporting_agent = EPMReportingAgent()

    def run(self, budget, actuals, period, threshold_pct=15, user_request=""):
        validation = self.data_agent.validate(budget, actuals)
        if validation["status"] != "PASS":
            raise ValueError(f"Data validation failed: {validation['issues']}")
        analysis = self.analysis_agent.analyse(budget, actuals, period)
        exceptions = self.anomaly_agent.detect(analysis, threshold_pct)
        commentary = self.commentary_agent.generate(exceptions, period, user_request)
        recommendations = self.reporting_agent.recommendations(exceptions)
        return {
            "data_validation": validation,
            "exceptions": exceptions,
            "commentary": commentary,
            "recommendations": recommendations
        }
