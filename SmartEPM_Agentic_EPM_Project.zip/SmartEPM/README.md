# SmartEPM — Agentic Financial Planning & Variance Analysis

A runnable EPM-inspired training project demonstrating budget-vs-actual analysis,
threshold-based exception detection, AI-generated commentary, and a five-agent workflow.

> This is a simulated EPM application. It is not Oracle EPM, Anaplan, OneStream, or SAP.
> All bundled financial data is synthetic.

## Features

- EPM-style dimensions: Account, Entity, Department, Scenario, Period and Version.
- Python/Pandas calculations for budget, actual, variance and variance percentage.
- Separate data, analysis, anomaly, commentary and reporting agents.
- Claude API integration for financial commentary when an API key is configured.
- Rule-based commentary fallback when no API key is configured.
- Streamlit dashboard and Excel report export.
- Unit test for the core variance calculation.

## Prerequisites

- Python 3.10 or newer
- VS Code
- Claude Code installed and authenticated if you want to use Claude Code to develop/modify the project
- Anthropic API key only if you want the running application to call Claude API

Claude Code and the Claude API are separate: using Claude Code in VS Code does not automatically provide an API key to this application.

## Run on Windows PowerShell

```powershell
cd SmartEPM
py -m venv .venv
.venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

## Run on Ubuntu/Linux

```bash
cd SmartEPM
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Open the local Streamlit URL printed in the terminal (normally http://localhost:8501).

## Enable Claude API commentary

1. Copy `.env.example` to `.env`.
2. Add your Anthropic API key to `ANTHROPIC_API_KEY`.
3. Set `CLAUDE_MODEL` to a model currently available to your Anthropic account.
4. Export the variables before starting Streamlit.

PowerShell:
```powershell
$env:ANTHROPIC_API_KEY="your-api-key"
$env:CLAUDE_MODEL="your-available-model-id"
streamlit run app.py
```

Ubuntu/Linux:
```bash
export ANTHROPIC_API_KEY="your-api-key"
export CLAUDE_MODEL="your-available-model-id"
streamlit run app.py
```

The project intentionally does not load `.env` automatically. Environment variables avoid accidentally committing secrets.
Never put API keys directly in Python files or commit them to Git.

## Demo walkthrough

1. Open the dashboard and select a period.
2. Review Budget, Actual and Net Variance.
3. Adjust the unfavourable variance threshold.
4. Select **Run EPM agent workflow**.
5. Review validation output, exception table, commentary and recommended actions.
6. Download the Excel variance report.
7. To demonstrate Claude Code, open this folder in VS Code and ask Claude Code to explain the project, add a new EPM dimension, or extend the agent workflow.

## Suggested Claude Code prompt

```text
Review this SmartEPM codebase before making changes.
Explain the data flow from CSV inputs through the five agents.
Then add a Scenario filter (Actual, Budget, Forecast) to the dashboard.
Preserve the rule that Python performs all financial calculations and Claude
is used only for interpretation and narrative. Add or update tests.
Do not invent EPM vendor API credentials or claim this is connected to Oracle EPM.
```

## Data model

The sample CSVs use these business dimensions:
- Period
- Entity
- Department
- Account
- Account Type (Revenue or Expense)

The sample planning dataset also includes Scenario and Version columns in the dimensional reference file.
The demo joins budget and actual data by Period, Entity, Department and Account.

## Run tests

```bash
pytest -q
```

## Important financial logic

- Expense: actual greater than budget is unfavourable.
- Revenue: actual greater than budget is favourable.
- Variance = Actual − Budget.
- Variance % = Variance / Budget × 100 (when budget is zero, the code uses a visible fallback convention).

For real EPM implementations, confirm sign conventions, account types, currency, exchange rates,
allocation logic, and consolidation rules with the finance team before using results operationally.
