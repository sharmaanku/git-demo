import pandas as pd

KEYS = ["Period", "Entity", "Department", "Account"]

def build_variance_analysis(budget: pd.DataFrame, actuals: pd.DataFrame, period: str | None = None) -> pd.DataFrame:
    """Join budget and actuals and calculate variances deterministically in Python."""
    b = budget.copy()
    a = actuals.copy()
    if period:
        b = b[b["Period"] == period]
        a = a[a["Period"] == period]
    merged = b.merge(a, on=KEYS, how="outer", suffixes=("_Budget", "_Actual"))
    merged["Budget"] = merged["Amount_Budget"].fillna(0)
    merged["Actual"] = merged["Amount_Actual"].fillna(0)
    merged["Account Type"] = merged["Account Type_Budget"].fillna(merged.get("Account Type_Actual"))
    merged["Variance"] = merged["Actual"] - merged["Budget"]
    merged["Variance %"] = merged.apply(
        lambda r: (r["Variance"] / r["Budget"] * 100) if r["Budget"] else (100.0 if r["Actual"] else 0.0),
        axis=1
    )
    def status(row):
        if row["Account Type"] == "Expense":
            return "Unfavourable" if row["Variance"] > 0 else "Favourable"
        return "Favourable" if row["Variance"] > 0 else "Unfavourable"
    merged["Variance Status"] = merged.apply(status, axis=1)
    cols = ["Period", "Entity", "Department", "Account", "Account Type",
            "Budget", "Actual", "Variance", "Variance %", "Variance Status"]
    return merged[cols].sort_values(["Department", "Account"]).reset_index(drop=True)
